from django.db import migrations, models

def set_default_profile_picture(apps, schema_editor):
    RiderProfile = apps.get_model('riders', 'RiderProfile')
    RiderProfile.objects.filter(profile_picture__isnull=True).update(profile_picture='../static/riders/images/default.jpg')

class Migration(migrations.Migration):

    dependencies = [
        ('riders', '0002_alter_riderprofile_profile_picture'),
    ]

    operations = [
        migrations.RunPython(set_default_profile_picture),
    ]
