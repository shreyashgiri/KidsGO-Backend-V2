from django.contrib import admin
from .models import RiderProfile, SavedAddresses



admin.site.register(RiderProfile)
admin.site.register(SavedAddresses)
