from django.contrib import admin
from .models import RideBooking

# Register your models here.

admin.site.register(RideBooking)